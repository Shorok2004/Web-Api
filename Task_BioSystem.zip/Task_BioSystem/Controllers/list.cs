﻿using System;
using System.Collections.Generic;
using Task_BioSystem.Models;

namespace Task_BioSystem.Controllers
{
    internal class list<T>
    {
        public static implicit operator list<T>(List<patient> v)
        {
            throw new NotImplementedException();
        }
    }
}