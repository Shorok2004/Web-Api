﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Task_BioSystem.Models;
using System.Web.Http.Results;

namespace Task_BioSystem.Controllers
{
    public class patientController : ApiController
    {
        List<patient> patients = new List<patient>() { new patient() { Id = 5, name = "shrouk" }, new patient() { Id = 8, name = "khaled" } };

        [HttpGet]
        public IHttpActionResult GetAllPatient()
        {
            return Ok(patients);
        }

        public IHttpActionResult GetPatient(int id)
        {
            var patient = patients.FirstOrDefault(x => x.Id == id);

            if (patient == null)
            {
                return BadRequest("Patient not found");
            }
            else
            {
                return Ok(patient);
            }
        }

        [HttpPost]
        public IHttpActionResult PostPatient([FromBody] patient patient)
        {
            if (ModelState.IsValid)
            {
                if (patients.Any(x => x.Id == patient.Id))
                {
                    return Conflict();
                }
                else
                {
                    patients.Add(patient);
                    return Ok(patient);
                }
            }
            else
            {
                return BadRequest();
            }
        }
    }
}
