﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Task_API.Models;

namespace Task_API.Controllers
{
    public class PatientController : ApiController
    {
        private readonly string connectionString = "Data Source=sql.bsite.net\\MSSQL2016;User ID=nunermien_303;Password=Nu@654321;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

        [HttpGet]
        public IHttpActionResult GetAllPatient(List<patients> patients)
        {
            List<patients> patientList = new List<patients>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT Id, Name, BirthDate, NationalId, City FROM Patients";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        patients patient = new patients
                        {
                            Id = (int)reader["Id"],
                            Name = reader["Name"].ToString(),
                            BirthDate = (DateTime)reader["BirthDate"],
                            NationalId = reader["NationalId"].ToString(),
                            City = reader["City"].ToString()
                        };

                        patientList.Add(patient);
                    }
                }
            }

            return Ok(patientList);
        }

        public IHttpActionResult GetPatient(int id)
        {
            patients patient = null;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT Id, Name, BirthDate, NationalId, City FROM Patients WHERE Id = @Id";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Id", id);

                connection.Open();
                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    patient = new patients
                    {
                        Id = (int)reader["Id"],
                        Name = reader["Name"].ToString(),
                        BirthDate = (DateTime)reader["BirthDate"],
                        NationalId = reader["NationalId"].ToString(),
                        City = reader["City"].ToString()
                    };
                }
            }

            if (patient == null)
            {
                return BadRequest("Patient not found");
            }
            else
            {
                return Ok(patient);
            }
        }

        [HttpPost]
        public IHttpActionResult PostPatient([FromBody] patients patient)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Patients (Name, BirthDate, NationalId, City) VALUES (@Name, @BirthDate, @NationalId, @City)";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Name", patient.Name);
                command.Parameters.AddWithValue("@BirthDate", patient.BirthDate);
                command.Parameters.AddWithValue("@NationalId", patient.NationalId);
                command.Parameters.AddWithValue("@City", patient.City);

                connection.Open();
                command.ExecuteNonQuery();
            }

            return Ok(patient);
        }
    }
}
