﻿using System;
using System.Net.Http;
using System.Collections.Generic;
using System.Threading.Tasks;
using Task_API.Models;
using System.Text;
using Newtonsoft.Json;

namespace Task_API
{
    class Program
    {
        public static async Task Main(string[] args)
        {
            var patient1 = new patients
            {
                Id = 1,
                Name = "John Doe",
                BirthDate = new DateTime(1990, 5, 15),
                NationalId = "123456789",
                City = "New York"
            };

            var patient2 = new patients
            {
                Id = 2,
                Name = "Jane Smith",
                BirthDate = new DateTime(1985, 8, 20),
                NationalId = "987654321",
                City = "Los Angeles"
            };

            var patients = new List<patients> { patient1, patient2 };

            await PostPatientsAsync(patients);
        }

        static async Task PostPatientsAsync(List<patients> patients)
        {
            string apiUrl = "https://localhost:44362/api/Patient";

            // Serialize patients to JSON
            string json = JsonConvert.SerializeObject(patients);

            using (HttpClient httpClient = new HttpClient())
            {
                // Create StringContent with JSON data
                StringContent content = new StringContent(json, Encoding.UTF8, "application/json");

                // PostAsync with appropriate Content-Type header
                HttpResponseMessage response = await httpClient.PostAsync(apiUrl, content);

                // Check response status
                if (response.IsSuccessStatusCode)
                {
                    Console.WriteLine("Patients added successfully.");
                }
                else
                {
                    Console.WriteLine($"Failed to add patients. Status code: {response.StatusCode}");
                }
            }
        }
    }
}
