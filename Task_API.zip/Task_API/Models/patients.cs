﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Task_API.Models
{
    public class patients
    {
        [Required]
        public string Name { get; set; }

        [Required]
        public DateTime BirthDate { get; set; }

        [Required]
        public string NationalId { get; set; }

        [Required]
        public string City { get; set; }
        public int Id { get; internal set; }
    }

    public class PatientRecordModel
    {
        [Required]
        public int PatientId { get; set; }

        [Required]
        public string Diagnosis { get; set; }

        [Required]
        public DateTime DateOfDiagnosis { get; set; }
    }
}